package data;

public class Action {
	public String user;
	public int value;
	public String field;
	
	public String getUser() {
		return user;
	}
	
	public int getValue() {
		return value;
	}
	
	public String getField() {
		return field;
	}
}
